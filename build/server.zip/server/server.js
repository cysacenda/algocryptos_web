"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bodyParser = require("body-parser");
const cors = require("cors");
const express = require("express");
const morgan = require("morgan");
// api
const coins_api_1 = require("./api/coins.api");
const errorHandler = require("errorhandler");
const pg_1 = require("pg");
const params_api_1 = require("./api/params.api");
const processes_api_1 = require("./api/processes.api");
const globaldata_api_1 = require("./api/globaldata.api");
/**
 * The server.
 *
 * @class Server
 */
// https://stackoverflow.com/questions/10870048/spawning-child-processes-in-an-express-server
class Server {
    /**
     * Bootstrap the application.
     * @static
     */
    static bootstrap(dbAdress) {
        return new Server(dbAdress);
    }
    /**
     * @constructor
     */
    constructor(dbAdress) {
        this.dbAdress = dbAdress;
        // create expressjs application
        this.app = express();
        // configure application
        this.config();
        // connect to database
        this.openConnection(this.dbAdress);
        // add api
        this.api();
    }
    /**
     * REST API endpoints.
     */
    api() {
        const router = express.Router();
        // configure CORS (Attention restriction à provenance http://localhost:4200
        const corsOptions = {
            allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'X-Access-Token'],
            credentials: true,
            methods: 'GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE',
            /*origin: 'http://localhost:4200',*/
            preflightContinue: false
        };
        router.use(cors(corsOptions));
        // root request
        router.get('/', (req, res, next) => {
            res.json({ announcement: 'Welcome to our API.' });
            next();
        });
        // create API routes
        coins_api_1.CoinsApi.create(router, this.pool);
        params_api_1.ParamsApi.create(router, this.pool);
        processes_api_1.ProcessesApi.create(router, this.pool);
        globaldata_api_1.GlobaldataApi.create(router, this.pool);
        // wire up the REST API
        this.app.use('/api', router);
        // enable CORS pre-flight
        router.options('*', cors(corsOptions));
    }
    /**
     * Configure application
     *
     * @class Server
     */
    config() {
        // morgan middleware to log HTTP requests
        this.app.use(morgan('dev'));
        // use json form parser middlware
        this.app.use(bodyParser.json());
        // use query string parser middlware
        this.app.use(bodyParser.urlencoded({
            extended: true
        }));
        // catch 404 and forward to error handler
        this.app.use(function (err, req, res, next) {
            err.status = 404;
            next(err);
        });
        // error handling
        this.app.use(errorHandler());
        /* this.app.use(function (req, res, next) {
          setTimeout(next, 1);
        }); */
    }
    openConnection(connectionString) {
        // https://node-postgres.com/
        this.pool = new pg_1.Pool({
            connectionString: connectionString,
        });
        this.pool.on('error', (err, client) => {
            console.error('Unexpected error on idle client', err);
        });
        /*this.pool.query('SELECT * from public.coins', (err, res) => {
          console.log(err, res);
          // this.pool.end();
        });*/
    }
}
exports.Server = Server;
//# sourceMappingURL=D:/Profiles/csacenda/WebstormProjects/algocryptos/dist/server/server.js.map