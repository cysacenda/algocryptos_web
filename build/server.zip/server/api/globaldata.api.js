"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class GlobaldataApi {
    static create(router, pool) {
        // GET
        router.get('/globaldata', (req, res, next) => {
            new GlobaldataApi().list(req, res, next, pool);
        });
    }
    // Get global data
    list(req, res, next, pool) {
        let squery = '';
        squery = 'select * from global_data';
        pool.query(squery, (err, resp) => {
            try {
                res.json(resp['rows']);
            }
            catch (error) {
                console.log(error);
            }
        });
    }
}
exports.GlobaldataApi = GlobaldataApi;
//# sourceMappingURL=D:/Profiles/csacenda/WebstormProjects/algocryptos/dist/server/api/globaldata.api.js.map