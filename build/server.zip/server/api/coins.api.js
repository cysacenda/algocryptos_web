"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CoinsApi {
    static create(router, pool) {
        // DELETE
        router.delete('/coins/:id([0-9a-f]{24})', (req, res, next) => {
            new CoinsApi().delete(req, res, next);
        });
        // GET
        router.get('/coins', (req, res, next) => {
            new CoinsApi().list(req, res, next, pool);
        });
        router.get('/coins/:id([0-9a-f]{24})', (req, res, next) => {
            new CoinsApi().get(req, res, next);
        });
        router.get('/missingCoins', (req, res, next) => {
            new CoinsApi().missingSocialCoins(req, res, next, pool);
        });
        // POST
        router.post('/coins', (req, res, next) => {
            new CoinsApi().create(req, res, next);
        });
        router.post('/missingCoins', (req, res, next) => {
            new CoinsApi().createSubreddit(req, res, next, pool);
        });
        // PUT
        router.put('/coins/:id([0-9a-f]{24})', (req, res, next) => {
            new CoinsApi().update(req, res, next);
        });
    }
    create(req, res, next) {
    }
    createSubreddit(req, res, next, pool) {
        const idCoinCryptoCompare = req.body.IdCoinCryptoCompare;
        const redditName = req.body.Reddit_name;
        const text = 'INSERT INTO social_infos_manual("IdCoinCryptoCompare", "Reddit_name") VALUES($1, $2) RETURNING *';
        const values = [idCoinCryptoCompare, redditName];
        pool.query(text, values, (err, response) => {
            if (err) {
                res.json({ Error: 'createSubreddit API' });
            }
            else {
                res.json(response.rows[0]);
            }
        });
    }
    delete(req, res, next) {
    }
    get(req, res, next) {
    }
    list(req, res, next, pool) {
        let squery = '';
        squery = 'select co."IdCryptoCompare", co."CoinName", co."Symbol", pr.price_usd, pr.market_cap_usd, pr.rank, replace(pr."Name", \' \', \'-\') as NameCMC, pr.percent_change_1h,\n';
        squery += 'pr.percent_change_24h, pr.percent_change_7d, sr."Reddit_subscribers" as reddit_subscribers, sr.timestamp as timestamp_reddit_subscribers,\n';
        squery += 'kp.subscribers_1d_trend, kp.subscribers_3d_trend, kp.subscribers_7d_trend, kp.subscribers_15d_trend, kp.subscribers_30d_trend, kp.subscribers_60d_trend,\n';
        squery += 'kp.subscribers_90d_trend, kp."timestamp" as timestamp_reddit_trend,\n';
        squery += 'CASE WHEN sm."Reddit_name" IS NULL THEN si."Reddit_name" ELSE sm."Reddit_name" END AS reddit_agr,\n';
        squery += 'kv.volume_mean_last_1h_vs_30d, kv.volume_mean_last_3h_30d, kv.volume_mean_last_6h_30d, kv.volume_mean_last_12h_30d, kv.volume_mean_last_24h_30d, kv.volume_mean_last_3d_30d, kv.volume_mean_last_7d_30d, kv.timestamp as timestamp_volumes,\n';
        squery += 'lohi.price_low_15d, lohi.date_low_15d, (pr.price_usd - lohi.price_low_15d) / lohi.price_low_15d as change_low_15d,\n';
        squery += 'lohi.price_high_15d, lohi.date_high_15d, (pr.price_usd - lohi.price_high_15d) / lohi.price_high_15d as change_high_15d,\n';
        squery += 'lohi.price_low_1m, lohi.date_low_1m, (pr.price_usd - lohi.price_low_1m) / lohi.price_low_1m as change_low_1m,\n';
        squery += 'lohi.price_high_1m, lohi.date_high_1m, (pr.price_usd - lohi.price_high_1m) / lohi.price_high_1m as change_high_1m,\n';
        squery += 'lohi.price_low_3m, lohi.date_low_3m, (pr.price_usd - lohi.price_low_3m) / lohi.price_low_3m as change_low_3m,\n';
        squery += 'lohi.price_high_3m, lohi.date_high_3m, (pr.price_usd - lohi.price_high_3m) / lohi.price_high_3m as change_high_3m,\n';
        squery += 'lohi.price_low_6m, lohi.date_low_6m, (pr.price_usd - lohi.price_low_6m) / lohi.price_low_6m as change_low_6m,\n';
        squery += 'lohi.price_high_6m, lohi.date_high_6m, (pr.price_usd - lohi.price_high_6m) / lohi.price_high_6m as change_high_6m,\n';
        squery += 'lohi.price_low_1y, lohi.date_low_1y, (pr.price_usd - lohi.price_low_1y) / lohi.price_low_1y as change_low_1y,\n';
        squery += 'lohi.price_high_1y, lohi.date_high_1y, (pr.price_usd - lohi.price_high_1y) / lohi.price_high_1y as change_high_1y,\n';
        squery += 'lohi.price_low_5y, lohi.date_low_5y, (pr.price_usd - lohi.price_low_5y) / lohi.price_low_5y as change_low_5y,\n';
        squery += 'lohi.price_high_5y, lohi.date_high_5y, (pr.price_usd - lohi.price_high_5y) / lohi.price_high_5y as change_high_5y\n';
        squery += 'from coins as co\n';
        squery += 'inner join prices as pr on (co."IdCryptoCompare" = pr."IdCryptoCompare")\n';
        squery += 'left outer join lower_higher_prices lohi on (lohi."IdCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'left outer join social_infos si on (si."IdCoinCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'left outer join social_infos_manual sm on (sm."IdCoinCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'left outer join social_stats_reddit sr on (sr."IdCoinCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'left outer join kpi_reddit_subscribers kp on (kp."IdCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'left outer join kpi_market_volumes kv on (kv."IdCoinCryptoCompare" = co."IdCryptoCompare")\n';
        squery += 'order by market_cap_usd desc\n';
        console.log(squery);
        pool.query(squery, (err, resp) => {
            try {
                res.json(resp['rows']);
            }
            catch (error) {
                console.log(error);
            }
            next();
        });
    }
    missingSocialCoins(req, res, next, pool) {
        let squery = '';
        squery += 'SELECT co."IdCryptoCompare", co."Symbol", co."Name", co."CoinName" , sim."Reddit_name" FROM social_infos si\n';
        squery += 'INNER JOIN coins co ON si."IdCoinCryptoCompare" = co."IdCryptoCompare"\n';
        squery += 'LEFT JOIN social_infos_manual sim ON sim."IdCoinCryptoCompare" = co."IdCryptoCompare"\n';
        squery += 'WHERE si."Reddit_name" IS NULL AND sim."Reddit_name" IS NULL;';
        pool.query(squery, (err, resp) => {
            console.log(err, resp);
            res.json(resp['rows']);
            next();
        });
    }
    update(req, res, next) {
    }
}
exports.CoinsApi = CoinsApi;
//# sourceMappingURL=C:/Users/cysac/WebstormProjects/algocryptos_web/dist/server/api/coins.api.js.map