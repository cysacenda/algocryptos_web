"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ParamsApi {
    static create(router, pool) {
        // GET
        router.get('/params/resetprocesses', (req, res, next) => {
            new ParamsApi().get(req, res, next, pool);
        });
    }
    create(req, res, next) {
    }
    delete(req, res, next) {
    }
    // Trick to allow unlock processes if needed
    get(req, res, next, pool) {
        let squery = '';
        squery = 'delete from process_params';
        pool.query(squery, (err, resp) => {
            next();
        });
    }
}
exports.ParamsApi = ParamsApi;
//# sourceMappingURL=D:/Profiles/csacenda/WebstormProjects/algocryptos/dist/server/api/params.api.js.map