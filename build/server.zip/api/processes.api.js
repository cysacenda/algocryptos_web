"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ProcessesApi {
    static create(router, pool) {
        // GET
        router.get('/processes', (req, res, next) => {
            new ProcessesApi().list(req, res, next, pool);
        });
    }
    list(req, res, next, pool) {
        let squery = '';
        squery = 'select "IdProcess", "Name", "Status", "timestamp"\n';
        squery += 'from process_params\n';
        squery += 'order by timestamp\n';
        pool.query(squery, (err, resp) => {
            // console.log(err, resp);
            // console.log(squery);
            res.json(resp['rows']);
            next();
        });
    }
}
exports.ProcessesApi = ProcessesApi;
//# sourceMappingURL=C:/Users/cysac/WebstormProjects/algocryptos_web/dist/server/api/processes.api.js.map